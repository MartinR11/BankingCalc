#ifndef BANKINGCALC_H
#define BANKINGCALC_H

#include <iostream>
using namespace std;

class BankingCalc {
public:
    // Constructors
    BankingCalc();
    BankingCalc(float t_initialInvest, float t_monthlyDep, float t_annInterest, float t_years);

    // Accessors
    float getInitInvest();
    float getMonthlyDep();
    float getAnnualInterest();
    float getYears();
    float getMonths();
    float getTotalAmt();
    float getInterestAmt();
    float getYearTotInterest();

    // Methods
    void dataInput();
    void printReport();

private:
    // Private variables used in calculations
    float initialInvest = 0;
    float monthlyDep = 0;
    float annInterest = 0;
    float years = 0;
    float months = 0;
    float totalAmt = 0;
    float interestAmt = 0;
    float yearTotInterest = 0;
};

#endif
#pragma once
